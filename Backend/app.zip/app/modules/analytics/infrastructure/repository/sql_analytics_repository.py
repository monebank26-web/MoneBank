from datetime import timedelta

from sqlalchemy import func, text
from sqlalchemy.orm import Session

from app.core.utils.fechas import fin_del_dia, hoy_colombia

from app.modules.analytics.domain.interface.analytics_repository import (
    AnalyticsRepository
)
from app.modules.ahorro.domain.entity.ahorro import Ahorro
from app.modules.ahorro.infrastructure.model.ahorro_model import AhorroModel
from app.modules.ahorro.infrastructure.model.tipo_ahorro_model import (
    TipoAhorroModel
)
from app.modules.transaccion.domain.entity.trans_entity import Transaccion
from app.modules.transaccion.infrastructure.model.categoria_model import (
    CategoriaModel
)
from app.modules.transaccion.infrastructure.model.historial_transaccion_model import (
    HistorialTransaccionModel
)


class SqlAnalyticsRepository(AnalyticsRepository):

    def __init__(self, db: Session):
        self.db = db

    def find_transaccion(self, id_usuario, id_transaccion):
        return (
            self.db.query(HistorialTransaccionModel)
            .filter(
                HistorialTransaccionModel.id_transaccion == id_transaccion,
                HistorialTransaccionModel.id_usuario == id_usuario,
            )
            .first()
        )

    def calcular_stats_mes(self, id_usuario):
        inicio_mes = hoy_colombia().replace(day=1)

        filtros = [
            HistorialTransaccionModel.id_usuario == id_usuario,
            HistorialTransaccionModel.tipo_transaccion == Transaccion.TIPO_GASTO,
            HistorialTransaccionModel.fecha >= inicio_mes,
        ]

        total_gastado_mes = (
            self.db.query(func.coalesce(func.sum(HistorialTransaccionModel.monto), 0))
            .filter(*filtros)
            .scalar()
        )

        top_categorias = (
            self.db.query(
                HistorialTransaccionModel.nombre_categoria.label("nombre_categoria"),
                func.sum(HistorialTransaccionModel.monto).label("total"),
            )
            .filter(*filtros)
            .group_by(HistorialTransaccionModel.nombre_categoria)
            .order_by(func.sum(HistorialTransaccionModel.monto).desc())
            .limit(3)
            .all()
        )

        return {
            "total_gastado_mes": total_gastado_mes or 0,
            "top_categorias": [
                {
                    "nombre_categoria": fila.nombre_categoria,
                    "total": fila.total,
                }
                for fila in top_categorias
            ],
        }

    def get_categoria_nombre(self, id_categoria):
        cat = (
            self.db.query(CategoriaModel)
            .filter(CategoriaModel.id_categoria == id_categoria)
            .first()
        )
        return cat.nombre_categoria if cat else None

    def get_resumen_categoria(self, id_usuario, id_categoria):
        hoy = hoy_colombia()
        inicio_mes = hoy.replace(day=1)
        inicio_mes_anterior = (inicio_mes - timedelta(days=1)).replace(day=1)
        fin_mes_anterior = inicio_mes - timedelta(days=1)
        hace_3_meses = hoy - timedelta(days=90)

        gasto_mes = self._sumar_transacciones_categoria(
            id_usuario, id_categoria, inicio_mes, hoy
        )
        gasto_mes_anterior = self._sumar_transacciones_categoria(
            id_usuario, id_categoria, inicio_mes_anterior, fin_mes_anterior
        )
        gasto_3_meses = self._sumar_transacciones_categoria(
            id_usuario, id_categoria, hace_3_meses, hoy
        )
        promedio = gasto_3_meses / 3 if gasto_3_meses else 0

        recientes = (
            self.db.query(HistorialTransaccionModel)
            .filter(
                HistorialTransaccionModel.id_usuario == id_usuario,
                HistorialTransaccionModel.id_categoria == id_categoria,
            )
            .order_by(HistorialTransaccionModel.fecha.desc())
            .limit(3)
            .all()
        )

        transacciones_recientes = []
        for t in recientes:
            fecha_t = t.fecha.date() if hasattr(t.fecha, "date") else t.fecha
            dias = (hoy - fecha_t).days
            if dias <= 0:
                fecha_relativa = "hoy"
            elif dias == 1:
                fecha_relativa = "ayer"
            else:
                fecha_relativa = f"hace {dias} días"
            transacciones_recientes.append({
                "monto": round(float(t.monto)),
                "fecha": fecha_relativa,
            })

        return {
            "gasto_mes": gasto_mes,
            "gasto_mes_anterior": gasto_mes_anterior,
            "promedio_3_meses": promedio,
            "num_transacciones_mes": self._contar_transacciones_categoria(
                id_usuario, id_categoria, inicio_mes, hoy
            ),
            "num_transacciones_mes_anterior": self._contar_transacciones_categoria(
                id_usuario, id_categoria, inicio_mes_anterior, fin_mes_anterior
            ),
            "transacciones_recientes": transacciones_recientes,
        }

    def get_limite_categoria(self, id_cuenta, id_categoria):
        tipo_limite = (
            self.db.query(TipoAhorroModel)
            .filter(
                TipoAhorroModel.nombre_tipo_ahorro == Ahorro.TIPO_LIMITE
            )
            .first()
        )
        if not tipo_limite:
            return None

        limite = (
            self.db.query(AhorroModel)
            .filter(
                AhorroModel.id_tipo_ahorro == tipo_limite.id_tipo_ahorro,
                AhorroModel.id_categoria == id_categoria,
                AhorroModel.id_cuenta == id_cuenta,
                AhorroModel.estado == "ACTIVO",
            )
            .first()
        )
        if not limite:
            return None

        rango = Ahorro.calcular_rango_periodo(limite.periodo, hoy_colombia())
        if not rango:
            return None

        fecha_desde, fecha_hasta = rango
        gasto_actual = self.db.execute(
            text(
                "SELECT fn_gasto_categoria_periodo("
                ":id_categoria, :id_cuenta, :fecha_desde, :fecha_hasta) AS total"
            ),
            {
                "id_categoria": id_categoria,
                "id_cuenta": id_cuenta,
                "fecha_desde": fecha_desde,
                "fecha_hasta": fecha_hasta,
            },
        ).scalar()

        return {
            "monto_limite": limite.monto_objetivo,
            "gasto_actual": gasto_actual or 0,
            "periodo": limite.periodo,
        }

    def obtener_datos_grafica(self, id_usuario, periodo=None):
        filtros = [
            HistorialTransaccionModel.id_usuario == id_usuario,
        ]

        series_temporales = (
            self.db.query(
                func.date(HistorialTransaccionModel.fecha).label("fecha"),
                HistorialTransaccionModel.tipo_transaccion,
                func.sum(HistorialTransaccionModel.monto).label("total")
            )
            .filter(*filtros)
            .group_by(func.date(HistorialTransaccionModel.fecha), HistorialTransaccionModel.tipo_transaccion)
            .order_by(func.date(HistorialTransaccionModel.fecha).asc())
            .all()
        )

        totales_por_categoria = (
            self.db.query(
                HistorialTransaccionModel.nombre_categoria.label("nombre_categoria"),
                HistorialTransaccionModel.tipo_transaccion,
                func.sum(HistorialTransaccionModel.monto).label("total")
            )
            .filter(*filtros)
            .group_by(HistorialTransaccionModel.nombre_categoria, HistorialTransaccionModel.tipo_transaccion)
            .order_by(func.sum(HistorialTransaccionModel.monto).desc())
            .all()
        )

        return {
            "series": [
                {
                    "fecha": row.fecha.isoformat() if hasattr(row.fecha, "isoformat") else str(row.fecha),
                    "tipo_transaccion": row.tipo_transaccion,
                    "total": row.total
                }
                for row in series_temporales
            ],
            "totales_por_categoria": [
                {
                    "nombre_categoria": row.nombre_categoria,
                    "tipo_transaccion": row.tipo_transaccion,
                    "total": row.total
                }
                for row in totales_por_categoria
            ]
        }

    def _sumar_transacciones_categoria(
        self, id_usuario, id_categoria, fecha_desde, fecha_hasta
    ):
        total = (
            self.db.query(
                func.coalesce(func.sum(HistorialTransaccionModel.monto), 0)
            )
            .filter(
                HistorialTransaccionModel.id_usuario == id_usuario,
                HistorialTransaccionModel.id_categoria == id_categoria,
                HistorialTransaccionModel.tipo_transaccion == Transaccion.TIPO_GASTO,
                HistorialTransaccionModel.fecha >= fecha_desde,
                HistorialTransaccionModel.fecha < fin_del_dia(fecha_hasta),
            )
            .scalar()
        )
        return total or 0

    def _contar_transacciones_categoria(
        self, id_usuario, id_categoria, fecha_desde, fecha_hasta
    ):
        return (
            self.db.query(
                func.count(HistorialTransaccionModel.id_transaccion)
            )
            .filter(
                HistorialTransaccionModel.id_usuario == id_usuario,
                HistorialTransaccionModel.id_categoria == id_categoria,
                HistorialTransaccionModel.tipo_transaccion == Transaccion.TIPO_GASTO,
                HistorialTransaccionModel.fecha >= fecha_desde,
                HistorialTransaccionModel.fecha < fin_del_dia(fecha_hasta),
            )
            .scalar()
            or 0
        )
    def obtener_movimientos_periodo(self, id_usuario, fecha_inicio, fecha_fin):
        filtros = [
            HistorialTransaccionModel.id_usuario == id_usuario,
            HistorialTransaccionModel.fecha >= fecha_inicio,
            HistorialTransaccionModel.fecha < fin_del_dia(fecha_fin),
        ]

        resultados = (
            self.db.query(
                HistorialTransaccionModel.tipo_transaccion,
                func.sum(HistorialTransaccionModel.monto).label("total")
            )
            .filter(*filtros)
            .group_by(HistorialTransaccionModel.tipo_transaccion)
            .all()
        )

        return [
            {"tipo_transaccion": row.tipo_transaccion, "total": row.total}
            for row in resultados
        ]
    def obtener_reporte_periodo(self, id_usuario, fecha_inicio, fecha_fin):
        filtros = [
            HistorialTransaccionModel.id_usuario == id_usuario,
            HistorialTransaccionModel.fecha >= fecha_inicio,
            HistorialTransaccionModel.fecha < fin_del_dia(fecha_fin),
        ]

        resultados = (
            self.db.query(
                HistorialTransaccionModel.nombre_categoria.label("nombre_categoria"),
                HistorialTransaccionModel.tipo_transaccion,
                func.sum(HistorialTransaccionModel.monto).label("total")
            )
            .filter(*filtros)
            .group_by(HistorialTransaccionModel.nombre_categoria, HistorialTransaccionModel.tipo_transaccion)
            .order_by(func.sum(HistorialTransaccionModel.monto).desc())
            .all()
        )

        total_metas = sum(
            row.total
            for row in resultados
            if row.tipo_transaccion == Transaccion.TIPO_MOVIMIENTO_AHORRO
        )

        return {
            "detalle_por_categoria": [
                {
                    "nombre_categoria": row.nombre_categoria,
                    "tipo_transaccion": row.tipo_transaccion,
                    "total": row.total,
                }
                for row in resultados
            ],
            "total_metas": total_metas or 0,
        }