from sqlalchemy import (
    Column,
    Integer,
    String,
    Numeric,
    Boolean,
    Date
)

from datetime import date

from app.core.database.base import Base


class AhorroModel(Base):
    __tablename__ = "ahorro"

    id_ahorro = Column(Integer, primary_key=True, index=True)

    nombre = Column(String(100), nullable=False)

    monto_objetivo = Column(Numeric(12, 2))
    saldo_inicial = Column(Numeric(12, 2))
    saldo_actual = Column(Numeric(12, 2))

    ahorro_automatico = Column(
        Boolean,
        nullable=False,
        default=False
    )

    fecha_creacion = Column(
        Date,
        default=date.today
    )

    estado = Column(String(20))

    fecha_objetivo = Column(Date, nullable=True)

    periodo = Column(String(20), nullable=True)

    fecha_finalizacion = Column(Date, nullable=True)

    id_tipo_ahorro = Column(Integer)
    id_categoria = Column(Integer)
    id_cuenta = Column(Integer)