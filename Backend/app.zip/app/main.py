from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.modules.usuario.presentation.router.router import (router as usuario_router)
from app.modules.ahorro.presentation.router.router import router as ahorro_router
from app.modules.cuenta.presentation.router.router import (router as cuenta_router)
from app.modules.auth.presentation.router.router import (router as auth_router)
from app.modules.transaccion.presentation.router.router import (
    router as transaccion_router
)
from app.modules.analytics.presentation.router.router import (
    router as analitica_router
)
from app.modules.programacion_ahorro.presentation.router.router import (
    router as programacion_ahorro_router
)
from app.modules.chat_ia.presentation.router.router import (
    router as chat_ia_router
)

from app.shared.exceptions.handlers import register_all_exception_handlers

from app.modules.control_parental.presentation.router.router import router as control_parental_router
from app.modules.control_parental.presentation.router.mesada_router import (
    router as mesada_parental_router,
)

from app.modules.control_parental.presentation.router.ejecucion_mesada_router import (
    router as ejecucion_mesada_router,
)

from app.modules.control_parental.presentation.router.gestionar_mesada_router import (
    router as gestionar_mesada_router,
)

app = FastAPI(title="MoneBank API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
def root():
    return {"message": "MoneBank monenando tu dinero."}


app.include_router(usuario_router)
app.include_router(auth_router)
app.include_router(ahorro_router)
app.include_router(cuenta_router)
app.include_router(transaccion_router)
app.include_router(analitica_router)
app.include_router(programacion_ahorro_router)
app.include_router(control_parental_router)
app.include_router(mesada_parental_router)
app.include_router(ejecucion_mesada_router)
app.include_router(gestionar_mesada_router)
app.include_router(chat_ia_router)

register_all_exception_handlers(app)
